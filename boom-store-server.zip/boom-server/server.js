require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_CODE = process.env.ADMIN_CODE || 'hevy&gefen';
const DATA_FILE = path.join(__dirname, 'data', 'products.json');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- storage helpers ----------
function readProducts() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    console.error('שגיאה בקריאת קובץ המוצרים:', e);
    return [];
  }
}
function writeProducts(products) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2), 'utf8');
}

// ---------- admin auth ----------
function requireAdmin(req, res, next) {
  const code = req.header('x-admin-code');
  if (!code || code !== ADMIN_CODE) {
    return res.status(401).json({ error: 'קוד ניהול שגוי' });
  }
  next();
}

// ---------- image upload ----------
const storage = multer.diskStorage({
  destination: UPLOADS_DIR,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('יש להעלות קובץ תמונה בלבד'));
    }
    cb(null, true);
  }
});

function deleteUploadedFileIfLocal(imagePath) {
  if (imagePath && imagePath.startsWith('/uploads/')) {
    const full = path.join(__dirname, 'public', imagePath);
    fs.unlink(full, () => {});
  }
}

// ---------- routes: public ----------
app.get('/api/products', (req, res) => {
  res.json(readProducts());
});

app.post('/api/admin/login', (req, res) => {
  const { code } = req.body || {};
  if (code === ADMIN_CODE) return res.json({ ok: true });
  res.status(401).json({ ok: false, error: 'קוד שגוי' });
});

// ---------- routes: admin ----------
app.post('/api/admin/products', requireAdmin, upload.single('imageFile'), (req, res) => {
  try {
    const products = readProducts();
    const { name, cat, price, ilPrice, paymentLink, imageUrl } = req.body;

    if (!name || !cat || !price) {
      return res.status(400).json({ error: 'חסרים שדות חובה: שם, קטגוריה ומחיר' });
    }

    const nextId = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
    const image = req.file ? '/uploads/' + req.file.filename : (imageUrl || null);

    const product = {
      id: nextId,
      cat: cat.trim(),
      name: name.trim(),
      price: Number(price),
      ilPrice: Number(ilPrice) || Number(price),
      image,
      icon: null,
      paymentLink: paymentLink ? paymentLink.trim() : null
    };

    products.push(product);
    writeProducts(products);
    res.json(product);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'שגיאת שרת בהוספת מוצר' });
  }
});

app.put('/api/admin/products/:id', requireAdmin, upload.single('imageFile'), (req, res) => {
  try {
    const products = readProducts();
    const id = Number(req.params.id);
    const existing = products.find(p => p.id === id);
    if (!existing) return res.status(404).json({ error: 'מוצר לא נמצא' });

    const { name, cat, price, ilPrice, paymentLink, imageUrl } = req.body;
    const oldImage = existing.image;

    if (name) existing.name = name.trim();
    if (cat) existing.cat = cat.trim();
    if (price) existing.price = Number(price);
    if (ilPrice) existing.ilPrice = Number(ilPrice);
    if (paymentLink !== undefined) existing.paymentLink = paymentLink.trim() || null;

    if (req.file) {
      existing.image = '/uploads/' + req.file.filename;
      deleteUploadedFileIfLocal(oldImage);
    } else if (imageUrl !== undefined && imageUrl.trim()) {
      existing.image = imageUrl.trim();
    }

    writeProducts(products);
    res.json(existing);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'שגיאת שרת בעדכון מוצר' });
  }
});

app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  try {
    const products = readProducts();
    const id = Number(req.params.id);
    const idx = products.findIndex(p => p.id === id);
    if (idx === -1) return res.status(404).json({ error: 'מוצר לא נמצא' });

    const [removed] = products.splice(idx, 1);
    deleteUploadedFileIfLocal(removed.image);
    writeProducts(products);
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'שגיאת שרת במחיקת מוצר' });
  }
});

// multer error handler
app.use((err, req, res, next) => {
  if (err) {
    console.error(err);
    return res.status(400).json({ error: err.message || 'שגיאה בבקשה' });
  }
  next();
});

app.listen(PORT, () => {
  console.log(`BOOM store server running on http://localhost:${PORT}`);
});
